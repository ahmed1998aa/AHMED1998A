 PAIN BOT

PAIN لتنصيب سورس  
افتح ترمنال وحط هذه الكودات 

git clone https://github.com/Abutbar/PAIN.git

cd PAIN

chmod +x install.sh

./install.sh

او نصب بكود واحد

git clone https://github.com/Abutbar/PAIN.git && cd PAIN && chmod +x install.sh && ./install.sh

● وراح يطلب منك تحط اما y او n تختار دائما y وانتر ●

🎩--------------------------------🎩 وراه من يتنصب اغلق كل الترمنال

🎩--------------------------------🎩 ● تفتح ترمنال وتحط 

redis-server

🎩--------------------------------🎩 ● وراه تروح ع ملف
PAIN.lua  وتخلي ايديك وايدي بوتك

● وسوي رن من الملف PAIN.sh 🎩--------------------------------🎩

DEV   @wwwala
DEV   @T_zap
 تابع قناة السورس ليصلك كلشي جديد 
 @vps_no
